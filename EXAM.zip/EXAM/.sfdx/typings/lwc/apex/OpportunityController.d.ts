declare module "@salesforce/apex/OpportunityController.getOpportunityList" {
  export default function getOpportunityList(): Promise<any>;
}
