import { LightningElement, api, wire, track } from 'lwc';
import getOpportunityList from '@salesforce/apex/OpportunityController.getOpportunityList';
import transactioncalculation from '@salesforce/apex/OpportunityController.transactioncalculation';
import { NavigationMixin } from 'lightning/navigation';


export default class PageLayout extends LightningElement {
    @api recordId;

@wire(getOpportunityList)
wiredOppsResult;


get opportunityList() {
return this.wiredOppsResult?.data || [];
}




async SetexpectedRevenue(event) {
const selectedOppId = event.target.dataset.id;

try {

await transactioncalculation({ oppId: selectedOppId });
this.ShowToastNotification(
    'Transaction Successful',
    'Update Successful',
    'success'
)

await refreshApex(this.wiredOppsResult);
} catch (error) {
console.error('Database process failed:', error.body.message);
}
}


ShowToastNotification(title,message,variant){
    this.title ;
    this.message;
    this.variant;
}






}